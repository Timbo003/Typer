import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JProgressBar;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JButton;


public class MainFrame extends JFrame {

	private JPanel contentPane;
	public JTextField InputTextField;
	public JLabel NextWordLabel;
	public JLabel CurrentWordLabel;
	public JProgressBar progressBar;
	public JLabel TimeLabel;
	public JLabel LastWordLabel;
	public JMenu Settings;
	public JMenuBar MenuBar;
	public JButton ChangePath;
	

	/**
	 * Create the frame.
	 */
	public MainFrame() {
		setTitle("Typer");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 750, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		InputTextField = new JTextField();
		InputTextField.setFont(new Font("Tahoma", Font.PLAIN, 22));
		InputTextField.setHorizontalAlignment(SwingConstants.CENTER);
		InputTextField.setBounds(166, 300, 400, 75);
		contentPane.add(InputTextField);
		InputTextField.setColumns(10);
		
		CurrentWordLabel = new JLabel("Current");
		CurrentWordLabel.setFont(new Font("Tahoma", Font.PLAIN, 22));
		CurrentWordLabel.setBounds(241, 206, 250, 50);
		CurrentWordLabel.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(CurrentWordLabel);
		
		NextWordLabel = new JLabel("Next");
		NextWordLabel.setForeground(Color.GRAY);
		NextWordLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		NextWordLabel.setBounds(524, 207, 200, 50);
		NextWordLabel.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(NextWordLabel);
		
		progressBar = new JProgressBar();
		progressBar.setBounds(10, 40, 714, 26);
		contentPane.add(progressBar);
		
//		TimeLabel = new JLabel("Time");
//		TimeLabel.setFont(new Font("Tahoma", Font.PLAIN, 16));
//		TimeLabel.setBounds(308, 48, 100, 25);
//		TimeLabel.setHorizontalAlignment(SwingConstants.CENTER);
//		contentPane.add(TimeLabel);
		
		LastWordLabel = new JLabel("New label");
		LastWordLabel.setForeground(new Color(51, 204, 51));
		LastWordLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		LastWordLabel.setHorizontalAlignment(SwingConstants.CENTER);
		LastWordLabel.setBounds(10, 207, 200, 50);
		contentPane.add(LastWordLabel);
		
		MenuBar = new JMenuBar();
		MenuBar.setBounds(0, 0, 60, 22);
		contentPane.add(MenuBar);
		
		Settings = new JMenu("Settings");
		Settings.setHorizontalAlignment(SwingConstants.CENTER);
		MenuBar.add(Settings);
		
		ChangePath = new JButton("Change Path");
		ChangePath.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				FileChooser chooser = new FileChooser();
			}
		});
		
		Settings.add(ChangePath);
	}
	private static void addPopup(Component component, final JPopupMenu popup) {
	}
}
