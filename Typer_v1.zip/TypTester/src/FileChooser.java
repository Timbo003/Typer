import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
public class FileChooser {

	public FileChooser() {
		FileNameExtensionFilter filter = new FileNameExtensionFilter(".txt", "txt");
		
		JFileChooser chooser = new JFileChooser();

		chooser.setFileFilter(filter);
		
		chooser.showSaveDialog(null);

		String path=chooser.getSelectedFile().getAbsolutePath();
//		String filename=chooser.getSelectedFile().getName();
		GameManager.changedPath = path;
		System.out.println("changed");
		
		chooser.showOpenDialog(null);
	}
}
