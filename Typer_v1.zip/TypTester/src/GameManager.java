import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GameManager {
	public MainFrame frame;

	public ArrayList<String> wordList = new ArrayList<>(); // list with the right words
	public ArrayList<String> userInput = new ArrayList<>(); // list with the user input
	
	
	public double  wrong = 1;
	public double  right = 1;
	
	public List<String> lines;
	public String lastWord;
	public String nextWord;
	public String currentWord;
	public static String path = "C:\\Users\\Tim\\Documents\\Projects\\Java\\eclipse-workspace\\TypTester\\src\\words.txt";
	public static String changedPath = "C:\\Users\\Tim\\Documents\\Projects\\Java\\eclipse-workspace\\TypTester\\src\\words.txt";

	
	
	public GameManager(MainFrame frame) {
		this.frame = frame;
		
		try {
            this.lines = Files.readAllLines(Paths.get(path));
        } catch (IOException e) {
            e.printStackTrace();
        }
		
		startGameRound();
		
	}

	private void startGameRound() {
		
		if (wordList.size() == 0) {
			setupFirstWordSet();
		}

		frame.InputTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_SPACE) {
					System.out.println("space");

					String inputWord = frame.InputTextField.getText().replace(" ", "");

					frame.InputTextField.setText(null);
					nextWords(inputWord);
				}
			}
		});

	}

	private void setupFirstWordSet() {
		this.setCurrentWord(getRandomWord());
		this.setNextWord(getRandomWord());
	}
	
	
	public void nextWords(String userInputString) { //soll next word neu machen, verschieben aufrufen und in die listen speichern
		if (this.path != this.changedPath) {
			try {
				System.out.println("try");
	            this.lines = Files.readAllLines(Paths.get(changedPath));
	            
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
		}
		
		this.wordList.add(this.currentWord);
		this.userInput.add(userInputString);
		System.out.println(this.wordList);
		System.out.println(this.userInput);
		
		this.moveWords();
	}
	
	
	public void moveWords() { //soll die woerter eins nach rechts verschieben
		this.setLastWord(this.currentWord);
		this.setCurrentWord(this.nextWord);
		this.setNextWord(getRandomWord());
		
//		System.out.println(this.userInput.get(this.userInput.size()-1) + " == " + this.wordList.get(this.wordList.size()-1));
		if (this.userInput.get(this.userInput.size()-1).equals(this.wordList.get(this.wordList.size()-1))) {
//			System.out.println("gleich");
			this.frame.LastWordLabel.setForeground(new Color(51, 204, 51));
			this.right++;
		}else {
			this.frame.LastWordLabel.setForeground(Color.red);
			this.wrong++;
		}
		calcPercentage();
	}
	
	private void calcPercentage() {
	
		double devision = this.right / this.wrong;
		devision = devision > 1 ? 1 : devision ;
		
		
		this.frame.progressBar.setValue((int) (devision*100));
		System.out.println(this.frame.progressBar.getValue());
	}
	
	private String getRandomWord() {
        Random random = new Random();
        return this.lines.get(random.nextInt(this.lines.size()));
    }

	
	public void setNextWord(String nextWord) {
		this.nextWord = nextWord;
		this.frame.NextWordLabel.setText(this.nextWord);
	}
	
	public void setCurrentWord(String currentWord) {
		this.currentWord = currentWord;
		this.frame.CurrentWordLabel.setText(currentWord);
	}
	
	public void setLastWord(String lastWord) {
		this.lastWord = lastWord;
		this.frame.LastWordLabel.setText(this.lastWord);
	}
}
