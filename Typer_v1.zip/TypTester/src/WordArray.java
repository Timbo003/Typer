public class WordArray {
	public static String[] words = {
			
	};
}
